/*
 * UART_Driver_05.c
 *
 * Created: 27/11/2020 06:21:11 م
 * Author : Ali
 */ 

#include "UART.h"
#include "LED.h"
#define F_CPU 8000000
#include <util/delay.h>




int main(void)
{
   
   uint8 uart_data_rec = 0;
   
   UART_Init();
   LED0_Init();
   LED1_Init();
   LED2_Init();
   
   
    while (1) 
    {
		uart_data_rec = UART_Rx();
		
		switch(uart_data_rec)
		{
			case('1'):
			LED0_Toggle();
			_delay_ms(500);
			break;
			
			case('2'):
			LED1_Toggle();
			_delay_ms(500);
			break;
			
			case('3'):
			LED2_Toggle();
			_delay_ms(500);
			break;
			
			default:
			break;
		}
		
	}

}

