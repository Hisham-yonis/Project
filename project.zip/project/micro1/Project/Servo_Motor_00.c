

#include "Servo_Motor_00.h"

void Servo_Init(void)
{
	DIO_SetPinDir(DIO_PORTD , DIO_PIN5 , DIO_PIN_OUTPUT);
	PWM1_Init();
	PWM1_Start();
	
}

void Servo_Move(uint8 DutyCycle)
{
	PWM1_Set_DutyCycle(DutyCycle);
}