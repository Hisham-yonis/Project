

#ifndef BUTTON_H_
#define BUTTON_H_

#include "DIO.h"
#define F_CPU 16000000
#include <util/delay.h>

typedef enum
{
	NOT_PRESSED,
	PRESSED
	}Button_Status;

void Button0_Init(void);

uint8 Button0_GetValue(void);


void Button1_Init(void);

uint8 Button1_GetValue(void);


void Button2_Init(void);

uint8 Button2_GetValue(void);



#endif /* BUTTON_H_ */