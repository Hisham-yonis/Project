﻿

#include "Temp.h"


void TempSensor_Init(void)
{
	ADC_Init();
}

uint16 TempSensor_Read(void)
{
	uint16  Digital_OutPut = 0;
	uint16  Temp = 0;
	
	Digital_OutPut = ADC_Read();
	
	Temp = (Digital_OutPut * 500) / 1024 ;
	
	return Temp;
	
}