

#include "Timers.h"

uint32 NUM_OVF = 0; // number of overflows 
uint32 Init_Value = 0;

uint32 Timer1_NUM_COMP = 0;

void Timer0_Init(void)
{
	// Select normal mode 
	CLR_BIT(TCCR0,3);
	CLR_BIT(TCCR0,6);
	
	// Enable Interrupts 
	SET_BIT(SREG, 7);  //enable global interrupts 
	SET_BIT(TIMSK, 0); //timer0 overflow interrupt enable 

}

void Timer0_Start(void)
{
	SET_BIT(TCCR0,0);
	CLR_BIT(TCCR0,1);
	SET_BIT(TCCR0,2);
}

void Timer0_Stop(void)
{
	CLR_BIT(TCCR0,0);
	CLR_BIT(TCCR0,1);
	CLR_BIT(TCCR0,2);
}

void Timer0_SetDelay(uint32 Delay_ms)
{
	uint8 Tick_Time = (1024 / 16);
	
	uint32 Total_Ticks = (Delay_ms * 1000) / Tick_Time ;
	
	NUM_OVF = Total_Ticks / 256;
	
	Init_Value = 256 - (Total_Ticks % 256) ; 
	
	TCNT0 = Init_Value ; 
	
	NUM_OVF++;
}


void Timer1_Init(void)
{
	SET_BIT(TCCR1B, 3); // timer1 mode 4 ( CTC -- OCR1A )
	
	SET_BIT(SREG, 7); // enable general interrupt 
	SET_BIT(TIMSK, 4); // peripeheral interrupt enable 
	
	
}

void Timer1_Start(void)
{
	/* setting prescaler 1024 */
	SET_BIT(TCCR1B, 0);
	CLR_BIT(TCCR1B, 1);
	SET_BIT(TCCR1B, 2);
	
	
}

void Timer1_Stop(void)
{
	CLR_BIT(TCCR1B, 0);
	CLR_BIT(TCCR1B, 1);
	CLR_BIT(TCCR1B, 2);
}

void Timer1_SetDelay(uint32 Delay_ms)
{
	if(Delay_ms <= 4000)
	{
		uint8 tick_time = 1024 /16; // the result in microsecond
		
		uint32 num_of_ticks = ( Delay_ms * 1000 / tick_time );
		
		OCR1A = num_of_ticks - 1;
		
		Timer1_NUM_COMP ++;
	}
}

void PWM0_Init(void)
{
	SET_BIT(DDRB , 3);
	
	// fast pwm
	SET_BIT(TCCR0, 3);
	SET_BIT(TCCR0, 6);
	
	//non inverted 
	SET_BIT(TCCR0, 5);
	
}

void PWM0_Set_DutyCycle(uint8 DutyCycle)
{
	OCR0 = ((DutyCycle * 256) / 100) - 1;
}

void PWM0_Start(void)
{
	//prescaler 256
	SET_BIT(TCCR0, 2);
	
}

void PWM1_Init(void)
{
	// timer1 mode 14
	SET_BIT(TCCR1A , 1);
	SET_BIT(TCCR1B , 3);
	SET_BIT(TCCR1B , 4);
	// select non inverted pwm mode 
	SET_BIT(TCCR1A , 7);	
	//control TOP value of timer1
	ICR1 = 1250;
	
}

void PWM1_Set_DutyCycle(uint8 DutyCycle)
{
	OCR1A = ((DutyCycle * 1250 ) / 100 ) - 1;
}

void PWM1_Start(void)
{
	// select prescaler 256 //
	SET_BIT(TCCR1B , 2);
}