/*
 * Timer.c
 *
 * Created: 1/26/2021 9:30:55 AM
 *  Author: hossam
 */ 
#include "Timer.h"

uint32 NUM_OVF =0;
uint32 Init_Value=0;
uint8 Timer1_Num_Comp =0;


void Timer0_Init(void)
{
	/* select normal mode*/
	CLR_Bit(TCCR0,3);
	CLR_Bit(TCCR0,6);
	
	/* Enable Interrupts */
	SET_Bit(SREG,7); //enable global interrupts
	SET_Bit(TIMSK,0); //enable Timer0 ovf Interrupt
	
}

void Timer0_Start(void)
{
	SET_Bit(TCCR0,0);
	CLR_Bit(TCCR0,1);
	SET_Bit(TCCR0,2);
}

void Timer0_Stop(void)
{
	CLR_Bit(TCCR0,0);
	CLR_Bit(TCCR0,1);
	CLR_Bit(TCCR0,2);
}

void Timer0_SetDelay(uint32 Delay_ms)
{
	uint8 Tick_Time = (1024 /16);
	
	uint32 Total_Ticks = (Delay_ms *1000) /Tick_Time ;
	
	NUM_OVF =Total_Ticks /256 ;
	
	Init_Value =256- (Total_Ticks %256);
	
	TCNT0 =Init_Value ;
	
	NUM_OVF ++; 
}










void Timer1_Init(void)
{
	SET_Bit(TCCR1B,3);        //select mode 4 of timer1
	
	SET_Bit(SREG,7);          //enable global interrupts
	SET_Bit(TIMSK,4);         //peripheral INT Enable
	
	
	
}

void Timer1_Start(void)
{
	/*Set prescler*/
	SET_Bit(TCCR1B,0);
	CLR_Bit(TCCR1B,1);
	SET_Bit(TCCR1B,2);
}

void Timer1_Stop(void)
{
		CLR_Bit(TCCR1B,0);
		CLR_Bit(TCCR1B,1);
		CLR_Bit(TCCR1B,2);
}

void Timer1_SetDelay(uint32 Delay_ms)
{
	if(Delay_ms <= 4000)
	{
		uint8 Tick_Time =1024/16;
		
		uint32 num_tickes=(Delay_ms *1000)/ Tick_Time;
		
		OCR1A = num_tickes -1; 
		
		Timer1_Num_Comp ++;
	}
} 