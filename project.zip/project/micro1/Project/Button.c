
#include "Button.h"


void Button0_Init(void)
{
	DIO_SetPinDir(DIO_PORTB,DIO_PIN0,DIO_PIN_INPUT);
}

uint8 Button0_GetValue(void)
{
	uint8 value;
	
	DIO_ReadPin(DIO_PORTB,DIO_PIN0, &value);
	
	while(GET_BIT(PINB,0)==1);
	
	_delay_ms(10);
	
	return value;
}



void Button1_Init(void)
{
	DIO_SetPinDir(DIO_PORTB,DIO_PIN4,DIO_PIN_INPUT);
}

uint8 Button1_GetValue(void)
{
	uint8 value;
	
	DIO_ReadPin(DIO_PORTB,DIO_PIN4, &value);
	
	while(Get_Bit(PINB,4)==1);
	
	_delay_ms(10);
	
	return value;
}



void Button2_Init(void)
{
	DIO_SetPinDir(DIO_PORTD,DIO_PIN2,DIO_PIN_INPUT);
}

uint8 Button2_GetValue(void)
{
	uint8 value;
	
	DIO_ReadPin(DIO_PORTD,DIO_PIN2, &value);
	
	while(Get_Bit(PINB,2)==1);
	
	_delay_ms(10);
	
	return value;
}