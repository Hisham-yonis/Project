

#ifndef SERVO_MOTOR_00_H_
#define SERVO_MOTOR_00_H_


#include "Timers.h"
#include "DIO.h"

void Servo_Init(void);

void Servo_Move(uint8 DutyCycle);


#endif /* SERVO_MOTOR_00_H_ */