/*
 * Timer.h
 *
 * Created: 1/26/2021 9:31:09 AM
 *  Author: hossam
 */ 


#ifndef TIMER_H_
#define TIMER_H_

#include "ATmega_Registers.h"
#include "BIT_MATH.h"

void Timer0_Init(void);

void Timer0_Start(void);

void Timer0_Stop(void);

void Timer0_SetDelay(uint32 Delay_ms);




void Timer1_Init(void);

void Timer1_Start(void);

void Timer1_Stop(void);

void Timer1_SetDelay(uint32 Delay_ms); 

#endif /* TIMER_H_ */