


#ifndef TIMERS_H_
#define TIMERS_H_
#include "ATmega32_Registers_00.h"
#include "BIT_MATH.h"

void Timer0_Init(void);

void Timer0_Start(void);

void Timer0_Stop(void);

void Timer0_SetDelay(uint32 Delay_ms);


void Timer1_Init(void);

void Timer1_Start(void);

void Timer1_Stop(void);

void Timer1_SetDelay(uint32 Delay_ms);


void PWM0_Init(void);

void PWM0_Set_DutyCycle(uint8 DutyCycle);

void PWM0_Start(void);


void PWM1_Init(void);

void PWM1_Set_DutyCycle(uint8 DutyCycle);

void PWM1_Start(void);

#endif /* TIMERS_H_ */