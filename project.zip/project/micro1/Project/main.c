/*
 * Project.c
 *
 * Created: 1/29/2021 9:18:28 AM
 * Author : Hisham
 */ 


#include "Temp.h"
#include "LCD.h"
#include "LED.h"
#include "Button.h"
#include "Servo_Motor_00.h"
#include "DC_Motor_00.h"
#include "SPI_00.h"


int main(void)
{
	
	DIO_SetPinDir(DIO_PORTC , DIO_PIN3 , DIO_PIN_OUTPUT);
	DIO_SetPinDir(DIO_PORTC , DIO_PIN4 , DIO_PIN_OUTPUT);
	
	

	 Servo_Init();
	
	
	uint16 temp = 0;
	
	LCD_Init();
	TempSensor_Init();
	LED0_Init();
	
	Button0_Init();
	Button_Status val;
	
	Button0_Init();
	
	LCD_WriteString("to start");
	LCD_Goto(1,0);
	LCD_WriteString("Click the Button");
	_delay_ms(400);
	LCD_Clear();
	LCD_WriteString("Max deg is 50");
	_delay_ms(400);
	LCD_Clear();
	
	
	
	LED0_Init();
	
	
	_delay_ms(500);
	
	uint8 x=3;
	while (1)
	{
		val =Button0_GetValue();
		
		if (val==PRESSED)
		{ 
			
			
			   while (1)
			   {
				   
				
				
				 _delay_ms(500);
				   temp = TempSensor_Read() ;
				   
				   LCD_Clear();
				   
				   LCD_WriteInteger(temp);
				   if (temp>=40)
				   {
					   DIO_SetPinVal(DIO_PORTC , DIO_PIN3 , DIO_PIN_HIGH);
					   DIO_SetPinVal(DIO_PORTC , DIO_PIN4 , DIO_PIN_LOW);
				   }
				   if (temp<40)
				   {
					   DIO_SetPinVal(DIO_PORTC , DIO_PIN3 , DIO_PIN_HIGH);
					   DIO_SetPinVal(DIO_PORTC , DIO_PIN4 , DIO_PIN_HIGH);
				   }
				   
				 
				   if (temp >=50)
				   {
					   LCD_Clear();
					   LCD_WriteInteger(temp);
					   LCD_Goto(1, 0);
					   LCD_WriteString("Warning");
					   LED0_ON();
					   _delay_ms(400);
					   LED0_OFF();
					   LCD_Clear();
					   
					  
					   Servo_Move(10);
					   
				   }
				   
			   }
		}
	}
	

	
}






